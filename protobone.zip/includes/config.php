/*
* Protobone Framework | v1.0.0 | MIT | July 4th, 2017
* Copyright 2017, Selwyn Orren @ Linuxweb
* Adapted from Skeleton Grid by Dave Gamache
* Free to use under the MIT license.
* http://www.opensource.org/licenses/mit-license.php
* 04/07/2017
*/

<?php
//  Config  ////

?>
